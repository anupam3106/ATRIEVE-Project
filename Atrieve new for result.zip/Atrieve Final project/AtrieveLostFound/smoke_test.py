import os
import sys
import traceback

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'AtrieveLostFound.settings')

import django
django.setup()

from django.test import Client
from django.contrib.auth.models import User

USERNAME = 'smoketest_user'
PASSWORD = 'Testpass123!'
EMAIL = 'smoketest@example.com'

client = Client(enforce_csrf_checks=True)

try:
    print('GET /signup/')
    r = client.get('/signup/')
    print('GET /signup/ status:', r.status_code)
    if 'csrftoken' not in r.cookies:
        print('No csrftoken cookie returned; failing')
        sys.exit(2)
    token = r.cookies['csrftoken'].value

    data = {
        'username': USERNAME,
        'email': EMAIL,
        'first_name': 'Smoke',
        'last_name': 'Test',
        'password1': PASSWORD,
        'password2': PASSWORD,
        'csrfmiddlewaretoken': token,
    }

    print('POST /signup/')
    r2 = client.post('/signup/', data, follow=True)
    print('POST /signup/ final status:', r2.status_code)
    print('Redirect chain:', r2.redirect_chain)

    created = User.objects.filter(username=USERNAME).exists()
    print('User created:', created)
    if not created:
        print('Signup did not create user.')
        sys.exit(3)

    # Logout
    client.get('/logout/')

    # Get CSRF on login page
    r3 = client.get('/auth/')
    print('GET /auth/ status:', r3.status_code)
    if 'csrftoken' not in r3.cookies:
        print('No csrftoken on auth page; failing')
        sys.exit(4)
    token2 = r3.cookies['csrftoken'].value

    login_data = {
        'username_or_email': USERNAME,
        'password': PASSWORD,
        'remember_me': 'on',
        'csrfmiddlewaretoken': token2,
    }
    r4 = client.post('/auth/', login_data, follow=True)
    print('POST /auth/ status:', r4.status_code)
    print('Redirect chain:', r4.redirect_chain)

    # Check logged in by accessing dashboard
    r5 = client.get('/dashboard/user/')
    print('/dashboard/user/ status:', r5.status_code)
    if r5.status_code == 200:
        print('Smoke test PASSED: signup and login succeeded')
        sys.exit(0)
    else:
        print('Smoke test FAILED: dashboard not accessible after login')
        sys.exit(5)

except Exception:
    traceback.print_exc()
    sys.exit(10)
