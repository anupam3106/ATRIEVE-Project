"""
URL configuration for AtrieveLostFound project.
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import RedirectView

try:
    import allauth.socialaccount.providers.google
    google_provider_available = True
except ImportError:
    google_provider_available = False

urlpatterns = [
    path('admin/', admin.site.urls),
]

if not google_provider_available:
    urlpatterns.append(
        path('accounts/google/login/', RedirectView.as_view(url='/accounts/3rdparty/', permanent=False))
    )

urlpatterns += [
    path('accounts/', include('allauth.urls')),
    path('', include('lostfound.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
