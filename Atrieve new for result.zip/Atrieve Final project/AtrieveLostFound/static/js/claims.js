const POLL_INTERVAL = 10000;

const updateClaimTimeline = async () => {
  if (!window.claimStatusPollUrl) {
    return;
  }

  try {
    const response = await fetch(window.claimStatusPollUrl, {
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'same-origin',
    });
    if (!response.ok) {
      return;
    }

    const data = await response.json();
    const timeline = document.getElementById('claimsTimeline');
    if (!timeline) {
      return;
    }

    const claims = data.claims || [];
    const html = claims.map(claim => `
      <div class="timeline-item">
        <div class="timeline-icon">🕒</div>
        <div class="timeline-content">
          <h3>${claim.item_name}</h3>
          <p>Status: <strong>${claim.status.replace('_', ' ')}</strong></p>
          <p>Requested: ${new Date(claim.requested_at).toLocaleString()}</p>
          <p>Updated: ${new Date(claim.updated_at).toLocaleString()}</p>
        </div>
      </div>
    `).join('');

    timeline.innerHTML = html || '<div class="empty-state">You have no claims yet.</div>';
  } catch (error) {
    console.error('Claim polling failed', error);
  }
};

const updateNotificationBadge = async () => {
  if (!window.notificationCountUrl) {
    return;
  }

  try {
    const response = await fetch(window.notificationCountUrl, {
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'same-origin',
    });
    if (!response.ok) {
      return;
    }

    const data = await response.json();
    let badge = document.querySelector('.notification-toggle .badge');
    const toggle = document.querySelector('.notification-toggle');
    if (!badge && toggle) {
      badge = document.createElement('span');
      badge.className = 'badge';
      toggle.appendChild(badge);
    }
    if (!badge) {
      return;
    }

    badge.textContent = data.unread_count || 0;
    badge.style.display = data.unread_count > 0 ? 'inline-flex' : 'none';
  } catch (error) {
    console.error('Notification polling failed', error);
  }
};

const playNotificationSound = () => {
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (error) {
    console.log('Notification sound skipped (audio not available)');
  }
};

const updateRecentNotifications = async () => {
  if (!window.recentNotificationsUrl) {
    return;
  }

  try {
    const response = await fetch(window.recentNotificationsUrl, {
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'same-origin',
    });
    if (!response.ok) {
      return;
    }

    const data = await response.json();
    const menu = document.getElementById('notificationMenu');
    if (!menu) {
      return;
    }

    const items = data.notifications || [];
    const unreadItems = items.filter(note => !note.is_read);
    
    // Play sound if there are new unread notifications
    if (unreadItems.length > 0 && window.recentNotificationsUrl) {
      if (!window.lastNotificationCount || unreadItems.length > window.lastNotificationCount) {
        playNotificationSound();
      }
      window.lastNotificationCount = unreadItems.length;
    }
    
    const listHtml = items.map(note => `
      <a class="notification-card ${note.is_read ? '' : 'unread'}" href="/notifications/open/${note.id}/">
        <div>
          <strong>${note.title}</strong>
          <p>${note.message}</p>
        </div>
        <small>${note.created_at}</small>
      </a>
    `).join('');

    const header = menu.querySelector('.notification-menu-header');
    if (header) {
      menu.innerHTML = '';
      menu.appendChild(header);
      menu.insertAdjacentHTML('beforeend', listHtml || '<div class="empty-state">No notifications yet.</div>');
    }
  } catch (error) {
    console.error('Recent notifications update failed', error);
  }
};

const toggleNotificationMenu = () => {
  const menu = document.getElementById('notificationMenu');
  if (!menu) {
    return;
  }
  menu.classList.toggle('open');
};

const closeNotificationMenu = (event) => {
  const menu = document.getElementById('notificationMenu');
  const toggle = document.getElementById('notificationToggle');
  if (!menu || !toggle) {
    return;
  }
  if (!menu.contains(event.target) && !toggle.contains(event.target)) {
    menu.classList.remove('open');
  }
};

if (window.claimStatusPollUrl) {
  updateClaimTimeline();
  setInterval(updateClaimTimeline, POLL_INTERVAL);
}
if (window.notificationCountUrl) {
  updateNotificationBadge();
  setInterval(updateNotificationBadge, POLL_INTERVAL);
}
if (window.recentNotificationsUrl) {
  updateRecentNotifications();
  setInterval(updateRecentNotifications, POLL_INTERVAL);
}

window.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('notificationToggle');
  if (toggle) {
    toggle.addEventListener('click', toggleNotificationMenu);
  }
  document.addEventListener('click', closeNotificationMenu);
});
