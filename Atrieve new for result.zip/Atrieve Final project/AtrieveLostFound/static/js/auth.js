document.addEventListener('DOMContentLoaded', () => {
  const tabs = document.querySelectorAll('.tab-button');
  const panels = document.querySelectorAll('.form-panel');

  const showPanel = (target) => {
    panels.forEach((panel) => {
      panel.id === target ? panel.classList.add('active') : panel.classList.remove('active');
    });
    tabs.forEach((tab) => {
      tab.dataset.target === target ? tab.classList.add('active') : tab.classList.remove('active');
    });
  };

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => showPanel(tab.dataset.target));
  });

  if (window.location.pathname.includes('/signup/') && document.querySelector('.tab-button[data-target="signup"]')) {
    showPanel('signup');
  }
});
