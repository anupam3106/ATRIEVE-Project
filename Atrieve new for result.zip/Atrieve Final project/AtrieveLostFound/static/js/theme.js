const storedTheme = localStorage.getItem('atrieveTheme');
const html = document.documentElement;
const toggleButton = document.getElementById('themeToggle');

const applyTheme = (theme) => {
  html.setAttribute('data-theme', theme);
  localStorage.setItem('atrieveTheme', theme);
  if (toggleButton) {
    toggleButton.textContent = theme === 'dark' ? '🌙' : '☀️';
  }
};

if (storedTheme) {
  applyTheme(storedTheme);
} else {
  applyTheme('light');
}

if (toggleButton) {
  toggleButton.addEventListener('click', () => {
    const nextTheme = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(nextTheme);
  });
}
