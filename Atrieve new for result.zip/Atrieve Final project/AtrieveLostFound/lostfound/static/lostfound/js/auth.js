// ================= DOM ELEMENTS =================

const welcomeScreen =
document.querySelector(".welcome-screen");

const signinForm =
document.querySelector(".signin-form");

const signupForm =
document.querySelector(".signup-form");

const signinOpenBtns =
document.querySelectorAll(".signin-open");

const signupOpenBtns =
document.querySelectorAll(".signup-open");

const backBtns =
document.querySelectorAll(".back-btn");

const googleBtn =
document.querySelector(".google-btn");


// ================= HIDE ALL SCREENS =================

const hideAllScreens = () => {

    [
        welcomeScreen,
        signinForm,
        signupForm
    ].forEach((screen) => {

        screen?.classList.remove("active-screen");

        screen?.classList.add("hidden-screen");

    });

};


// ================= OPEN SIGN IN =================

signinOpenBtns.forEach((btn) => {

    btn.addEventListener("click", () => {

        hideAllScreens();

        signinForm?.classList.remove("hidden-screen");

        signinForm?.classList.add("active-screen");

    });

});


// ================= OPEN SIGN UP =================

signupOpenBtns.forEach((btn) => {

    btn.addEventListener("click", () => {

        hideAllScreens();

        signupForm?.classList.remove("hidden-screen");

        signupForm?.classList.add("active-screen");

    });

});


// ================= BACK BUTTON =================

backBtns.forEach((btn) => {

    btn.addEventListener("click", () => {

        hideAllScreens();

        welcomeScreen?.classList.remove("hidden-screen");

        welcomeScreen?.classList.add("active-screen");

    });

});


// ================= TOAST FUNCTION =================

const showToast = (
message,
type = "success"
) => {

    const toast =
    document.createElement("div");

    toast.className =
    `toast ${type}`;

    toast.innerHTML = `

        <i class="${
            type === "success"
            ? "ri-checkbox-circle-fill"
            : "ri-error-warning-fill"
        }"></i>

        <span>${message}</span>

    `;

    document.body.appendChild(toast);

    setTimeout(() => {

        toast.classList.add("show-toast");

    }, 100);

    setTimeout(() => {

        toast.classList.remove("show-toast");

        setTimeout(() => {

            toast.remove();

        }, 400);

    }, 3000);

};


// ================= GOOGLE BUTTON =================

if (googleBtn) {

    googleBtn.addEventListener("click", () => {

        showToast(
            "Google Login Coming Soon 🚀",
            "success"
        );

    });

}


// ================= TOAST CSS =================

const style =
document.createElement("style");

style.innerHTML = `

.toast{

    position:fixed;

    top:30px;
    right:30px;

    min-width:280px;

    padding:16px 22px;

    background:rgba(15,23,42,.95);

    border:1px solid rgba(255,255,255,.08);

    backdrop-filter:blur(20px);

    color:#fff;

    border-radius:18px;

    display:flex;
    align-items:center;
    gap:12px;

    z-index:9999;

    transform:translateX(120%);

    opacity:0;

    transition:.4s ease;

    box-shadow:
    0 18px 45px rgba(0,0,0,.35);

}

.show-toast{

    transform:translateX(0);

    opacity:1;

}

.toast i{

    font-size:1.3rem;

    color:#38bdf8;

}

.toast.error i{

    color:#ef4444;

}

`;

document.head.appendChild(style);


// ================= PARALLAX EFFECT =================

window.addEventListener("mousemove", (e) => {

    const blur1 =
    document.querySelector(".blur1");

    const blur2 =
    document.querySelector(".blur2");

    if (!blur1 && !blur2) return;

    const x =
    e.clientX / window.innerWidth;

    const y =
    e.clientY / window.innerHeight;

    if (blur1) {

        blur1.style.transform =
        `translate(${x * 30}px, ${y * 30}px)`;

    }

    if (blur2) {

        blur2.style.transform =
        `translate(-${x * 30}px, -${y * 30}px)`;

    }

});