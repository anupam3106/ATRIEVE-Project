document.addEventListener("DOMContentLoaded", () => {
    console.log("Atrieve About Page Loaded 🚀");

    // simple hover effect log
    document.querySelectorAll(".team-card").forEach(card => {
        card.addEventListener("click", () => {
            console.log("Card clicked");
        });
    });
});