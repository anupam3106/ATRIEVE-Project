/* ══════════════════════════════════════
   ATRIEVE – Lost Items  |  lost_items.js
   Fully Updated Modern Version
   ══════════════════════════════════════ */

/* ════════════════════
   USER CONFIG
   ════════════════════ */
const CURRENT_USER = window.ATRIEVE_USER || {
  name: 'User',
  email: 'user@atrieve.com',
  username: 'user'
};

/* ════════════════════
   DATA
   ════════════════════ */
const ITEMS = [
  { id: 1,  type: 'lost',  title: 'Black Leather Wallet',    category: 'Accessories', location: 'Central Park, NY',     date: 'May 3, 2026',  icon: 'ti-wallet' },
  { id: 2,  type: 'lost',  title: 'Dell Laptop XPS 15',      category: 'Electronics', location: 'Grand Station, NY',    date: 'May 5, 2026',  icon: 'ti-device-laptop' },
  { id: 3,  type: 'found', title: 'Blue JanSport Backpack',  category: 'Bags',        location: 'Metro Station B2',     date: 'May 6, 2026',  icon: 'ti-backpack' },
  { id: 4,  type: 'lost',  title: 'iPhone 15 Pro',           category: 'Electronics', location: 'Times Square, NY',     date: 'May 7, 2026',  icon: 'ti-device-mobile' },
  { id: 5,  type: 'found', title: 'Gold Ring',               category: 'Accessories', location: 'Riverside Park',       date: 'May 8, 2026',  icon: 'ti-circle' },
  
];

/* ════════════════════
   STATE
   ════════════════════ */
let activeType = 'all';
let activeCat  = 'All Categories';

/* ════════════════════
   HELPERS
   ════════════════════ */
function getGreeting() {
  const hour = new Date().getHours();

  if (hour >= 5 && hour < 12) {
    return 'Good Morning 👋';
  }

  if (hour >= 12 && hour < 17) {
    return 'Good Afternoon 👋';
  }

  if (hour >= 17 && hour < 22) {
    return 'Good Evening 👋';
  }

  return 'Good Night 🌙';
}

function getInitial(name) {
  return (name || 'U').charAt(0).toUpperCase();
}

function showToast(message) {

  let toast = document.getElementById('globalToast');

  if (!toast) {

    toast = document.createElement('div');
    toast.id = 'globalToast';
    toast.className = 'global-toast';

    document.body.appendChild(toast);
  }

  toast.textContent = message;

  toast.classList.add('show');

  setTimeout(() => {
    toast.classList.remove('show');
  }, 2600);
}

/* ════════════════════
   GREETING
   ════════════════════ */
function initGreeting() {

  const greetLine = document.getElementById('greetLine');

  if (greetLine) {
    greetLine.textContent = getGreeting();
  }

  setInterval(() => {

    if (greetLine) {
      greetLine.textContent = getGreeting();
    }

  }, 60000);
}

/* ════════════════════
   USER INFO
   ════════════════════ */
function applyUserData(user) {

  const name = user.name || user.username || 'User';
  const email = user.email || 'user@atrieve.com';

  const initial = getInitial(name);

  ['avatar', 'dropAvatar', 'modalAvatar'].forEach(id => {

    const el = document.getElementById(id);

    if (el) {
      el.textContent = initial;
    }
  });

  const unameEl = document.getElementById('uname');
  const dropName = document.getElementById('dropName');
  const dropEmail = document.getElementById('dropEmail');

  if (unameEl) {
    unameEl.textContent = name;
  }

  if (dropName) {
    dropName.textContent = name;
  }

  if (dropEmail) {
    dropEmail.textContent = email;
  }

  const editName = document.getElementById('editName');
  const editEmail = document.getElementById('editEmail');

  if (editName) {
    editName.value = name;
  }

  if (editEmail) {
    editEmail.value = email;
  }
}

/* ════════════════════
   PROFILE DROPDOWN
   ════════════════════ */
function initDropdown() {

  const chip = document.getElementById('userChip');
  const dropdown = document.getElementById('profileDropdown');

  if (!chip || !dropdown) return;

  chip.addEventListener('click', (e) => {

    e.stopPropagation();

    dropdown.classList.toggle('open');
    chip.classList.toggle('open');
  });

  document.addEventListener('click', (e) => {

    if (
      !chip.contains(e.target) &&
      !dropdown.contains(e.target)
    ) {
      dropdown.classList.remove('open');
      chip.classList.remove('open');
    }
  });
}

/* ════════════════════
   MODAL
   ════════════════════ */
function initModal() {

  const overlay = document.getElementById('modalOverlay');

  const editBtn = document.getElementById('editProfileBtn');

  const closeBtn = document.getElementById('modalClose');

  const cancelBtn = document.getElementById('btnCancel');

  const saveBtn = document.getElementById('btnSave');

  const dropdown = document.getElementById('profileDropdown');

  function openModal() {

    overlay.classList.add('open');

    document.body.style.overflow = 'hidden';

    dropdown.classList.remove('open');
  }

  function closeModal() {

    overlay.classList.remove('open');

    document.body.style.overflow = '';
  }

  if (editBtn) {
    editBtn.addEventListener('click', openModal);
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', closeModal);
  }

  if (cancelBtn) {
    cancelBtn.addEventListener('click', closeModal);
  }

  if (overlay) {

    overlay.addEventListener('click', (e) => {

      if (e.target === overlay) {
        closeModal();
      }
    });
  }

  if (saveBtn) {

    saveBtn.addEventListener('click', (e) => {

      e.preventDefault();

      const newName = document.getElementById('editName').value.trim();

      const newEmail = document.getElementById('editEmail').value.trim();

      if (!newName) {
        showToast('⚠️ Name is required');
        return;
      }

      CURRENT_USER.name = newName;
      CURRENT_USER.email = newEmail;

      applyUserData(CURRENT_USER);

      closeModal();

      showToast('✅ Profile updated');
    });
  }
}

/* ════════════════════
   BUILD CATEGORY LIST
   ════════════════════ */
function buildCategoryList() {

  const categories = [
    'All Categories',
    ...new Set(ITEMS.map(item => item.category))
  ];

  const catList = document.getElementById('catList');

  if (!catList) return;

  catList.innerHTML = categories.map((cat, index) => {

    return `
      <div
        class="filter-opt ${index === 0 ? 'active' : ''}"
        data-cat="${cat}"
        onclick="setCat(this, '${cat}')"
      >
        ${cat}
      </div>
    `;

  }).join('');
}

/* ════════════════════
   TYPE FILTER
   ════════════════════ */
function setType(el, value) {

  document.querySelectorAll('[data-type]').forEach(item => {
    item.classList.remove('active');
  });

  el.classList.add('active');

  activeType = value;

  applyFilters();
}

/* ════════════════════
   CATEGORY FILTER
   ════════════════════ */
function setCat(el, value) {

  document.querySelectorAll('[data-cat]').forEach(item => {
    item.classList.remove('active');
  });

  el.classList.add('active');

  activeCat = value;

  applyFilters();
}

/* ════════════════════
   APPLY FILTERS
   ════════════════════ */
function applyFilters() {

  const globalSearch =
    document.getElementById('globalSearch')?.value
      .toLowerCase()
      .trim() || '';

  const nameSearch =
    document.getElementById('nameSearch')?.value
      .toLowerCase()
      .trim() || '';

  const locationSearch =
    document.getElementById('locFilter')?.value
      .toLowerCase()
      .trim() || '';

  const finalQuery = `${globalSearch} ${nameSearch}`;

  const filtered = ITEMS.filter(item => {

    const typeMatch =
      activeType === 'all' ||
      item.type === activeType;

    const catMatch =
      activeCat === 'All Categories' ||
      item.category === activeCat;

    const searchMatch =
      !finalQuery ||
      item.title.toLowerCase().includes(finalQuery) ||
      item.category.toLowerCase().includes(finalQuery);

    const locationMatch =
      !locationSearch ||
      item.location.toLowerCase().includes(locationSearch);

    return (
      typeMatch &&
      catMatch &&
      searchMatch &&
      locationMatch
    );
  });

  const pill = document.getElementById('resultsPill');

  if (pill) {
    pill.textContent = `${filtered.length} results`;
  }

  renderItems(filtered);
}

/* ════════════════════
   RENDER ITEMS
   ════════════════════ */
function renderItems(items) {

  const grid = document.getElementById('itemsGrid');

  const emptyState = document.getElementById('emptyState');

  if (!grid || !emptyState) return;

  if (items.length === 0) {

    grid.style.display = 'none';

    emptyState.style.display = 'flex';

    return;
  }

  emptyState.style.display = 'none';

  grid.style.display = 'grid';

  grid.innerHTML = items.map(item => {

    return `
      <div class="item-card">

        <div class="card-top">

          <div class="card-icon ${item.type}">
            <i class="ti ${item.icon}"></i>
          </div>

          <div class="card-info">

            <div class="card-title">
              ${item.title}
            </div>

            <div class="card-sub">
              ${item.category} • ${item.date}
            </div>

          </div>

          <span class="badge ${item.type}">
            ${item.type}
          </span>

        </div>

        <div class="card-footer">

          <i class="ti ti-map-pin"></i>

          <span>
            ${item.location}
          </span>

        </div>

      </div>
    `;

  }).join('');
}

/* ════════════════════
   SIDEBAR ACTIVE
   ════════════════════ */
function initSidebarActive() {

  const navItems = document.querySelectorAll('.nav-item');

  navItems.forEach(item => {

    item.addEventListener('click', () => {

      navItems.forEach(nav => {
        nav.classList.remove('active');
      });

      item.classList.add('active');
    });
  });
}

/* ════════════════════
   INIT
   ════════════════════ */
document.addEventListener('DOMContentLoaded', () => {

  initGreeting();

  applyUserData(CURRENT_USER);

  initDropdown();

  initModal();

  initSidebarActive();

  buildCategoryList();

  applyFilters();

});