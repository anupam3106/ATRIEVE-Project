// ============================================================
//  USER CONFIG — yahan apna data daalo (ya login se set karo)
// ============================================================
const CURRENT_USER = window.ATRIEVE_USER || {
  name: 'User',
  email: '',
  username: 'user'
};


// ============================================================
//  HELPERS
// ============================================================

function getGreeting() {

  const h = new Date().getHours();

  if (h >= 5 && h < 12) return 'Good Morning 👋';

  if (h >= 12 && h < 17) return 'Good Afternoon 👋';

  if (h >= 17 && h < 21) return 'Good Evening 👋';

  return 'Good Night 👋';

}

function getInitial(name) {

  return (name || 'U')
    .charAt(0)
    .toUpperCase();

}

function showToast(msg) {

  let toast = document.getElementById('globalToast');

  if (!toast) {

    toast = document.createElement('div');

    toast.id = 'globalToast';
    toast.className = 'toast';

    document.body.appendChild(toast);

  }

  toast.textContent = msg;

  toast.classList.add('show');

  setTimeout(() => {

    toast.classList.remove('show');

  }, 2800);

}


// ============================================================
//  INIT
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // ==========================================================
  //  GREETING
  // ==========================================================

  const greetLine = document.getElementById('greetLine');

  if (greetLine) {

    greetLine.textContent = getGreeting();

  }

  setInterval(() => {

    if (greetLine) {

      greetLine.textContent = getGreeting();

    }

  }, 60000);


  // ==========================================================
  //  APPLY USER DATA
  // ==========================================================

  function applyUser(user) {

    const initial = getInitial(user.name);

    ['avatar', 'dropAvatar', 'modalAvatar'].forEach(id => {

      const el = document.getElementById(id);

      if (el) {

        el.textContent = initial;

      }

    });

    const unameEl   = document.getElementById('uname');
    const dropName  = document.getElementById('dropName');
    const dropEmail = document.getElementById('dropEmail');

    if (unameEl) {

      unameEl.textContent = user.name;

    }

    if (dropName) {

      dropName.textContent = user.name;

    }

    if (dropEmail) {

      dropEmail.textContent = user.email;

    }

  }

  applyUser(CURRENT_USER);


  // ==========================================================
  //  SIDEBAR TOGGLE
  // ==========================================================

  const sidebar  = document.getElementById('sidebar');
  const overlay  = document.getElementById('overlay');

  const menuBtn  = document.getElementById('menuBtn');
  const closeBtn = document.getElementById('sidebarClose');

  function openSidebar() {

    if (sidebar && overlay) {

      sidebar.classList.add('open');

      overlay.classList.add('show');

      document.body.style.overflow = 'hidden';

    }

  }

  function closeSidebar() {

    if (sidebar && overlay) {

      sidebar.classList.remove('open');

      overlay.classList.remove('show');

      document.body.style.overflow = '';

    }

  }

  if (menuBtn) {

    menuBtn.addEventListener('click', openSidebar);

  }

  if (closeBtn) {

    closeBtn.addEventListener('click', closeSidebar);

  }

  if (overlay) {

    overlay.addEventListener('click', () => {

      closeSidebar();

      closeDropdown();

    });

  }


  // ==========================================================
  //  SIDEBAR ACTIVE NAV
  // ==========================================================

  const sidebarNav = document.getElementById('sidebarNav');

  if (sidebarNav) {

    const navLinks =
      sidebarNav.querySelectorAll('.nav-link[data-page]');

    navLinks.forEach(link => {

      link.addEventListener('click', (e) => {

        e.preventDefault();

        navLinks.forEach(nav => {

          nav.classList.remove('active');

        });

        link.classList.add('active');

        if (window.innerWidth < 900) {

          closeSidebar();

        }

        showToast(
          '📂 Opening: ' + link.textContent.trim()
        );

      });

    });

  }


  // ==========================================================
  //  PROFILE DROPDOWN
  // ==========================================================

  const userChip =
    document.getElementById('userChip');

  const profileDropdown =
    document.getElementById('profileDropdown');

  function openDropdown() {

    if (profileDropdown && userChip) {

      profileDropdown.classList.add('show');

      userChip.classList.add('open');

    }

  }

  function closeDropdown() {

    if (profileDropdown && userChip) {

      profileDropdown.classList.remove('show');

      userChip.classList.remove('open');

    }

  }

  function toggleDropdown() {

    if (!profileDropdown) return;

    profileDropdown.classList.contains('show')
      ? closeDropdown()
      : openDropdown();

  }

  if (userChip) {

    userChip.addEventListener('click', (e) => {

      e.stopPropagation();

      toggleDropdown();

    });

  }

  // close dropdown outside click

  document.addEventListener('click', (e) => {

    if (
      profileDropdown &&
      userChip &&
      !userChip.contains(e.target) &&
      !profileDropdown.contains(e.target)
    ) {

      closeDropdown();

    }

  });


  // ==========================================================
  //  EDIT PROFILE MODAL
  // ==========================================================

  const editProfileBtn =
    document.getElementById('editProfileBtn');

  const modalOverlay =
    document.getElementById('modalOverlay');

  const modalClose =
    document.getElementById('modalClose');

  const btnCancel =
    document.getElementById('btnCancel');

  const btnSave =
    document.getElementById('btnSave');

  const editName =
    document.getElementById('editName');

  const editEmail =
    document.getElementById('editEmail');

  const editPhone =
    document.getElementById('editPhone');


  function openModal() {

    closeDropdown();

    if (
      editName &&
      editEmail &&
      editPhone &&
      modalOverlay
    ) {

      editName.value  = CURRENT_USER.name;

      editEmail.value = CURRENT_USER.email;

      editPhone.value =
        CURRENT_USER.phone || '';

      modalOverlay.classList.add('show');

      document.body.style.overflow = 'hidden';

      setTimeout(() => {

        editName.focus();

      }, 100);

    }

  }

  function closeModal() {

    if (modalOverlay) {

      modalOverlay.classList.remove('show');

      document.body.style.overflow = '';

    }

  }

  if (editProfileBtn) {

    editProfileBtn.addEventListener(
      'click',
      openModal
    );

  }

  if (modalClose) {

    modalClose.addEventListener(
      'click',
      closeModal
    );

  }

  if (btnCancel) {

    btnCancel.addEventListener(
      'click',
      closeModal
    );

  }

  if (modalOverlay) {

    modalOverlay.addEventListener('click', (e) => {

      if (e.target === modalOverlay) {

        closeModal();

      }

    });

  }


  // ==========================================================
  //  SAVE PROFILE
  // ==========================================================

  if (btnSave) {

    btnSave.addEventListener('click', () => {

      const newName =
        editName.value.trim();

      const newEmail =
        editEmail.value.trim();

      if (!newName) {

        editName.focus();

        return;

      }

      if (!newEmail) {

        editEmail.focus();

        return;

      }

      CURRENT_USER.name  = newName;

      CURRENT_USER.email = newEmail;

      CURRENT_USER.phone =
        editPhone.value.trim();

      applyUser(CURRENT_USER);

      closeModal();

      showToast(
        '✅ Profile updated successfully!'
      );

    });

  }


  // ==========================================================
  //  LOGOUT
  // ==========================================================

  const logoutBtn =
    document.getElementById('logoutBtn');

  if (logoutBtn) {

    logoutBtn.addEventListener('click', () => {

      closeDropdown();

      const confirmLogout =
        confirm(
          'Are you sure you want to logout?'
        );

      if (confirmLogout) {

        showToast(
          '👋 Logging out...'
        );

        setTimeout(() => {

          // Replace with your login page
          window.location.href = '/login/';

        }, 1200);

      }

    });

  }

});