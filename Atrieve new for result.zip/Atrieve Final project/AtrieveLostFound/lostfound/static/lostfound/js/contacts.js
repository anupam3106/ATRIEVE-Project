// ================= CONTACT CARD ANIMATION =================

const infoItems = document.querySelectorAll('.info-item');

const socialIcons = document.querySelectorAll('.developer-socials a');

const contactCard = document.querySelector('.contact-card');


// ================= PAGE LOAD ANIMATION =================

window.addEventListener('load', () => {

    contactCard.style.opacity = '1';

    contactCard.style.transform = 'translateY(0px)';

});


// ================= INITIAL STATE =================

contactCard.style.opacity = '0';

contactCard.style.transform = 'translateY(40px)';

contactCard.style.transition = '0.8s ease';


// ================= INFO ITEM HOVER EFFECT =================

infoItems.forEach((item) => {

    item.addEventListener('mouseenter', () => {

        item.style.transform = 'translateY(-6px)';

    });

    item.addEventListener('mouseleave', () => {

        item.style.transform = 'translateY(0px)';

    });

});


// ================= SOCIAL ICON ROTATION =================

socialIcons.forEach((icon) => {

    icon.addEventListener('mouseenter', () => {

        icon.style.transform = 'translateY(-6px) rotate(8deg) scale(1.08)';

    });

    icon.addEventListener('mouseleave', () => {

        icon.style.transform = 'translateY(0px) rotate(0deg) scale(1)';

    });

});


// ================= BUTTON CLICK EFFECT =================

const contactBtn = document.querySelector('.contact-btn');

contactBtn.addEventListener('click', () => {

    contactBtn.innerHTML = `
        Sending...
        <i class="ri-loader-4-line"></i>
    `;

});