// Navbar shadow on scroll
document.addEventListener("DOMContentLoaded", function () {
    const navbar = document.querySelector(".navbar");

    window.addEventListener("scroll", function () {
        if (window.scrollY > 50) {
            navbar.style.boxShadow = "0 10px 30px rgba(0,0,0,0.2)";
        } else {
            navbar.style.boxShadow = "none";
        }
    });
});

// ================= AUTH REDIRECT =================

const authBtn =
document.querySelector(".auth-redirect");

const signupBtn =
document.querySelector(".signup-redirect");

const googleBtn =
document.querySelector(".google-redirect");


// SIGN IN

authBtn.addEventListener("click", () => {

    window.location.href = "/auth/";

});


// SIGN UP

signupBtn.addEventListener("click", () => {

    window.location.href =
    "/auth/?form=signup";

});


// GOOGLE

googleBtn.addEventListener("click", () => {

    window.location.href =
    "/accounts/google/login/";

});