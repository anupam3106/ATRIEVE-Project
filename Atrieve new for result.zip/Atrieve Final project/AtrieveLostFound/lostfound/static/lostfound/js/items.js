// ================= SELECT ELEMENTS =================

const filterBtns = document.querySelectorAll(".filter-btn");
const searchInput = document.querySelector(".search-box input");
const itemCards = document.querySelectorAll(".item-card");

let activeFilter = "all";


// ================= GET CATEGORY =================

const getCategory = (card) => {

    return card
    .querySelector(".item-category")
    .innerText
    .toLowerCase();

};


// ================= GET STATUS =================

const getStatus = (card) => {

    return card
    .querySelector(".status")
    .innerText
    .toLowerCase();

};


// ================= FILTER FUNCTION =================

const filterItems = () => {

    const searchValue = searchInput.value.toLowerCase();

    itemCards.forEach((card) => {

        const title =
        card.querySelector("h3").innerText.toLowerCase();

        const description =
        card.querySelector("p").innerText.toLowerCase();

        const location =
        card.querySelector(".item-footer span")
        .innerText
        .toLowerCase();

        const category = getCategory(card);
        const status = getStatus(card);

        // ================= SEARCH MATCH =================

        const matchesSearch =

            title.includes(searchValue) ||
            description.includes(searchValue) ||
            location.includes(searchValue) ||
            category.includes(searchValue);

        // ================= FILTER MATCH =================

        let matchesFilter = false;

        if(activeFilter === "all"){

            matchesFilter = true;

        }

        else if(activeFilter === "lost" ||
                activeFilter === "found"){

            matchesFilter = status.includes(activeFilter);

        }

        else{

            matchesFilter =
            category.includes(activeFilter);

        }

        // ================= SHOW / HIDE =================

        if(matchesSearch && matchesFilter){

            card.style.display = "block";

            setTimeout(() => {

                card.style.opacity = "1";
                card.style.transform = "translateY(0px)";

            }, 100);

        }

        else{

            card.style.opacity = "0";
            card.style.transform = "translateY(30px)";

            setTimeout(() => {

                card.style.display = "none";

            }, 300);

        }

    });

};


// ================= FILTER BUTTON CLICK =================

filterBtns.forEach((btn) => {

    btn.addEventListener("click", () => {

        // REMOVE ACTIVE
        filterBtns.forEach((button) => {
            button.classList.remove("active");
        });

        // ADD ACTIVE
        btn.classList.add("active");

        // SET FILTER
        activeFilter =
        btn.innerText.toLowerCase().trim();

        // FILTER ITEMS
        filterItems();

    });

});


// ================= SEARCH INPUT =================

searchInput.addEventListener("keyup", () => {

    filterItems();

});


// ================= SAVE BUTTON =================

const saveBtns = document.querySelectorAll(".save-btn");

saveBtns.forEach((btn) => {

    btn.addEventListener("click", () => {

        btn.classList.toggle("saved");

        if(btn.classList.contains("saved")){

            btn.innerHTML =
            `<i class="ri-bookmark-fill"></i>`;

            btn.style.background = "#2563eb";
            btn.style.color = "#fff";

        }

        else{

            btn.innerHTML =
            `<i class="ri-bookmark-line"></i>`;

            btn.style.background =
            "rgba(255,255,255,0.2)";

            btn.style.color = "#fff";

        }

    });

});


// ================= REVEAL ANIMATION =================

const cards = document.querySelectorAll(".item-card");

const revealCards = () => {

    const triggerBottom =
    window.innerHeight * 0.85;

    cards.forEach((card, index) => {

        const cardTop =
        card.getBoundingClientRect().top;

        if(cardTop < triggerBottom){

            setTimeout(() => {

                card.classList.add("show-card");

            }, index * 120);

        }

    });

};

window.addEventListener("scroll", revealCards);
window.addEventListener("load", revealCards);


// ================= PARALLAX EFFECT =================

window.addEventListener("mousemove", (e) => {

    const blur1 = document.querySelector(".blur1");
    const blur2 = document.querySelector(".blur2");

    let x = e.clientX / window.innerWidth;
    let y = e.clientY / window.innerHeight;

    blur1.style.transform =
    `translate(${x * 30}px, ${y * 30}px)`;

    blur2.style.transform =
    `translate(-${x * 30}px, -${y * 30}px)`;

});


// ================= NO RESULTS MESSAGE =================

const itemsGrid = document.querySelector(".items-grid");

const noResults = document.createElement("div");

noResults.classList.add("no-results");

noResults.innerHTML = `
    
    <i class="ri-search-eye-line"></i>
    <h3>No Items Found</h3>
    <p>Try searching with different keywords.</p>

`;

itemsGrid.appendChild(noResults);


// ================= CHECK RESULTS =================

const checkResults = () => {

    let visibleCards = 0;

    itemCards.forEach((card) => {

        if(card.style.display !== "none"){

            visibleCards++;

        }

    });

    if(visibleCards === 0){

        noResults.style.display = "flex";

    }

    else{

        noResults.style.display = "none";

    }

};


// ================= UPDATE FILTER =================

const originalFilterItems = filterItems;

filterItems = () => {

    originalFilterItems();

    setTimeout(() => {

        checkResults();

    }, 400);

};


// ================= DYNAMIC STYLE =================

const style = document.createElement("style");

style.innerHTML = `

    .item-card{

        opacity:0;
        transform:translateY(60px);

        transition:
        opacity .5s ease,
        transform .5s ease;

    }

    .show-card{

        opacity:1 !important;
        transform:translateY(0px) !important;

    }

    .no-results{

        width:100%;
        min-height:320px;

        display:none;
        flex-direction:column;
        justify-content:center;
        align-items:center;

        gap:12px;

        border-radius:30px;

        background:rgba(255,255,255,0.65);

        border:1px solid rgba(255,255,255,0.45);

        backdrop-filter:blur(20px);

        color:#64748b;

        text-align:center;

        grid-column:1/-1;

    }

    .no-results i{

        font-size:3rem;
        color:#2563eb;

    }

`;

document.head.appendChild(style);


// ================= INITIAL LOAD =================

filterItems();

