from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('lostfound', '0003_alter_founditem_options_alter_lostitem_options_and_more'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name='claim',
            name='full_name',
            field=models.CharField(blank=True, max_length=120, default=''),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='claim',
            name='email',
            field=models.EmailField(blank=True, max_length=254, default=''),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='claim',
            name='phone_number',
            field=models.CharField(blank=True, max_length=30, default=''),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='claim',
            name='proof_of_ownership',
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name='claim',
            name='proof_image',
            field=models.FileField(blank=True, null=True, upload_to='claim_proofs/'),
        ),
        migrations.AddField(
            model_name='claim',
            name='reviewed_by',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='reviewed_claims', to=settings.AUTH_USER_MODEL),
        ),
        migrations.CreateModel(
            name='ActivityLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('action', models.CharField(max_length=180)),
                ('notes', models.TextField(blank=True)),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('staff', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='activity_logs', to=settings.AUTH_USER_MODEL)),
                ('target_claim', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='activity_logs', to='lostfound.claim')),
            ],
            options={
                'ordering': ['-timestamp'],
            },
        ),
    ]
