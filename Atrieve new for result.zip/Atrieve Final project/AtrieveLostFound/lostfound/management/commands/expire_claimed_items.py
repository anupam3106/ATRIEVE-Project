from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from lostfound.models import FoundItem, LostItem, Claim


class Command(BaseCommand):
    help = 'Expire approved claimed items after 12 hours and mark them closed.'

    def handle(self, *args, **options):
        expiration_threshold = timezone.now() - timedelta(hours=12)
        expired_lost = LostItem.objects.filter(
            is_claimed=True,
            is_active=True,
            approved_at__lte=expiration_threshold,
        )
        expired_found = FoundItem.objects.filter(
            is_claimed=True,
            is_active=True,
            approved_at__lte=expiration_threshold,
        )

        total_expired = 0
        for item in expired_lost:
            item.is_active = False
            item.save()
            Claim.objects.filter(lost_item=item, status='approved').update(status='returned')
            total_expired += 1

        for item in expired_found:
            item.is_active = False
            item.save()
            Claim.objects.filter(found_item=item, status='approved').update(status='returned')
            total_expired += 1

        self.stdout.write(self.style.SUCCESS(f'Expired {total_expired} claimed items.'))
