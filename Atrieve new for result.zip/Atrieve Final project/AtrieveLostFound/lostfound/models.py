from django.contrib.auth.models import User
from django.contrib.auth.signals import user_logged_in
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from datetime import timedelta

CATEGORY_CHOICES = [
    ('electronics', 'Electronics'),
    ('accessories', 'Accessories'),
    ('documents', 'Documents'),
    ('fashion', 'Fashion'),
    ('travel', 'Travel'),
    ('others', 'Others'),
]

CLAIM_STATUS_CHOICES = [
    ('pending', 'Pending'),
    ('under_review', 'Under Review'),
    ('approved', 'Approved'),
    ('rejected', 'Rejected'),
    ('returned', 'Item Returned'),
]

THEME_CHOICES = [
    ('light', 'Light'),
    ('dark', 'Dark'),
]


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone = models.CharField(max_length=30, blank=True)
    preferred_theme = models.CharField(max_length=10, choices=THEME_CHOICES, default='light')
    profile_image = models.FileField(upload_to='profile_photos/', blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.user.username} profile'


class LostItem(models.Model):
    name = models.CharField(max_length=120)
    category = models.CharField(max_length=30, choices=CATEGORY_CHOICES, default='others')
    description = models.TextField()
    location = models.CharField(max_length=120)
    date_lost = models.DateField()
    contact_email = models.EmailField(blank=True)
    contact_phone = models.CharField(max_length=30, blank=True)
    image = models.FileField(upload_to='lost_items/', blank=True, null=True)
    reported_by = models.ForeignKey(
        User, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='lost_items'
    )
    matched_found_item = models.ForeignKey(
        'FoundItem', null=True, blank=True,
        on_delete=models.SET_NULL, related_name='matched_lost_items'
    )
    reported_at = models.DateTimeField(default=timezone.now)
    is_claimed = models.BooleanField(default=False)
    approved_at = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-reported_at']

    def __str__(self):
        return self.name

    def mark_as_approved(self):
        self.is_claimed = True
        self.approved_at = timezone.now()
        self.is_active = True
        self.save()

    def expire_if_needed(self):
        if self.is_claimed and self.approved_at and self.is_active:
            expiry = self.approved_at + timedelta(hours=12)
            if timezone.now() >= expiry:
                self.is_active = False
                self.save()
                return True
        return False

    @property
    def expiry_time(self):
        return self.approved_at + timedelta(hours=12) if self.approved_at else None

    @property
    def time_until_expiry(self):
        if not self.expiry_time:
            return None
        remaining = self.expiry_time - timezone.now()
        return remaining if remaining.total_seconds() > 0 else timedelta(0)

    @property
    def status_label(self):
        if not self.is_claimed:
            return 'Available'
        if self.is_active:
            return 'Returning Soon'
        return 'Closed'

    @property
    def can_be_claimed(self):
        return self.is_active and not self.is_claimed


class FoundItem(models.Model):
    name = models.CharField(max_length=120)
    category = models.CharField(max_length=30, choices=CATEGORY_CHOICES, default='others')
    description = models.TextField()
    location = models.CharField(max_length=120)
    date_found = models.DateField()
    image = models.FileField(upload_to='found_items/', blank=True, null=True)
    reported_by = models.ForeignKey(
        User, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='found_items'
    )
    matched_lost_item = models.ForeignKey(
        LostItem, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='matched_found_items'
    )
    reported_at = models.DateTimeField(default=timezone.now)
    is_claimed = models.BooleanField(default=False)
    approved_at = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-reported_at']

    def __str__(self):
        return self.name

    def mark_as_approved(self):
        self.is_claimed = True
        self.approved_at = timezone.now()
        self.is_active = True
        self.save()

    def expire_if_needed(self):
        if self.is_claimed and self.approved_at and self.is_active:
            expiry = self.approved_at + timedelta(hours=12)
            if timezone.now() >= expiry:
                self.is_active = False
                self.save()
                return True
        return False

    @property
    def expiry_time(self):
        return self.approved_at + timedelta(hours=12) if self.approved_at else None

    @property
    def time_until_expiry(self):
        if not self.expiry_time:
            return None
        remaining = self.expiry_time - timezone.now()
        return remaining if remaining.total_seconds() > 0 else timedelta(0)

    @property
    def status_label(self):
        if not self.is_claimed:
            return 'Available'
        if self.is_active:
            return 'Returning Soon'
        return 'Closed'

    @property
    def can_be_claimed(self):
        return self.is_active and not self.is_claimed


class Claim(models.Model):
    requester = models.ForeignKey(User, on_delete=models.CASCADE, related_name='claims')
    found_item = models.ForeignKey(
        FoundItem,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='claims_found',
    )
    lost_item = models.ForeignKey(
        LostItem,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='claims_lost',
    )
    full_name = models.CharField(max_length=120, blank=True)
    email = models.EmailField(blank=True)
    phone_number = models.CharField(max_length=30, blank=True)
    proof_of_ownership = models.TextField(blank=True)
    note = models.TextField('Description', blank=True)
    proof_image = models.FileField(upload_to='claim_proofs/', blank=True, null=True)
    reviewed_by = models.ForeignKey(
        User, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='reviewed_claims'
    )
    status = models.CharField(max_length=20, choices=CLAIM_STATUS_CHOICES, default='pending')
    requested_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-requested_at']

    def __str__(self):
        item = self.associated_item
        item_name = item.name if item else 'Unknown'
        return f'Claim {self.id} by {self.requester.username} for {item_name}'

    @property
    def associated_item(self):
        return self.found_item or self.lost_item

    @property
    def item_type(self):
        if self.found_item is not None:
            return 'found'
        if self.lost_item is not None:
            return 'lost'
        return 'unknown'

    def item_date(self):
        if self.found_item:
            return self.found_item.date_found
        if self.lost_item:
            return self.lost_item.date_lost
        return None


class ActivityLog(models.Model):
    staff = models.ForeignKey(User, on_delete=models.CASCADE, related_name='activity_logs')
    action = models.CharField(max_length=180)
    target_claim = models.ForeignKey(Claim, null=True, blank=True, on_delete=models.SET_NULL, related_name='activity_logs')
    notes = models.TextField(blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        claim_ref = f' claim={self.target_claim.id}' if self.target_claim else ''
        return f'[{self.timestamp}] {self.staff.username}: {self.action}{claim_ref}'


class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=120)
    message = models.TextField()
    link = models.CharField(max_length=255, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.title} ({"read" if self.is_read else "unread"})'


@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)


@receiver(user_logged_in)
def create_staff_login_activity(sender, user, request, **kwargs):
    if user.is_staff or user.is_superuser:
        ActivityLog.objects.create(
            staff=user,
            action='Staff login',
            notes=f'User {user.username} logged in',
        )
