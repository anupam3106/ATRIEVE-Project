from django.conf import settings
from django.contrib import messages
from django.contrib.messages import get_messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import JsonResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.csrf import ensure_csrf_cookie
from datetime import timedelta

from allauth.socialaccount.models import SocialApp

from .forms import (
    ClaimRequestForm,
    ClaimItemForm,
    ClaimStatusUpdateForm,
    FoundItemForm,
    LoginForm,
    LostItemForm,
    SettingsForm,
    SignUpForm,
    UserProfileForm,
)
from .models import ActivityLog, Claim, FoundItem, LostItem, Notification, UserProfile


def _redirect_by_role(user):
    if user.is_superuser:
        return redirect('admin_dashboard')
    if user.is_staff:
        return redirect('staff_dashboard')
    return redirect('user_dashboard')


def _send_notification(user, title, message, link=''):
    if not user or not user.is_authenticated:
        return
    if Notification.objects.filter(
        user=user,
        title=title,
        message=message,
        link=link,
        is_read=False,
    ).exists():
        return
    Notification.objects.create(user=user, title=title, message=message, link=link)


def _notify_other_users(exclude_user, title, message, link=''):
    recipients = User.objects.filter(is_active=True).exclude(pk=exclude_user.pk)
    notifications = []
    for recipient in recipients:
        if not Notification.objects.filter(
            user=recipient,
            title=title,
            message=message,
            link=link,
            is_read=False,
        ).exists():
            notifications.append(Notification(user=recipient, title=title, message=message, link=link))
    if notifications:
        Notification.objects.bulk_create(notifications)


def _notify_staff(title, message, link=''):
    recipients = User.objects.filter(is_active=True).filter(Q(is_staff=True) | Q(is_superuser=True))
    notifications = []
    for recipient in recipients:
        if not Notification.objects.filter(
            user=recipient,
            title=title,
            message=message,
            link=link,
            is_read=False,
        ).exists():
            notifications.append(Notification(user=recipient, title=title, message=message, link=link))
    if notifications:
        Notification.objects.bulk_create(notifications)


def _expire_claimed_items():
    expiration_threshold = timezone.now() - timedelta(hours=12)
    LostItem.objects.filter(is_claimed=True, is_active=True, approved_at__lte=expiration_threshold).update(is_active=False)
    FoundItem.objects.filter(is_claimed=True, is_active=True, approved_at__lte=expiration_threshold).update(is_active=False)


def _match_found_with_lost(found_item):
    if not found_item:
        return
    matches = LostItem.objects.filter(
        matched_found_item__isnull=True,
    ).filter(
        Q(name__icontains=found_item.name) | Q(location__icontains=found_item.location)
    ).exclude(reported_by=found_item.reported_by)[:1]

    if not matches:
        return

    lost_item = matches[0]
    lost_item.matched_found_item = found_item
    lost_item.save(update_fields=['matched_found_item'])

    found_item.matched_lost_item = lost_item
    found_item.save(update_fields=['matched_lost_item'])

    if lost_item.reported_by:
        _send_notification(
            lost_item.reported_by,
            'Potential match found',
            f'A found item that may match your lost item "{lost_item.name}" was reported.',
            reverse('claim_status'),
        )

    if found_item.reported_by:
        _send_notification(
            found_item.reported_by,
            'Match candidate detected',
            f'Your found item "{found_item.name}" appears to match a lost report in the system.',
            reverse('notifications'),
        )


def _dashboard_context(request, active_page='dashboard'):
    return {
        'active_page': active_page,
        'notification_count': getattr(request, 'notification_count', 0),
        'active_user': request.user,
    }


def landing(request):
    return render(request, 'lostfound/landing.html', {'active_page': 'landing'})


def developer(request):
    return render(request, 'lostfound/developer.html', {'active_page': 'developer'})


def portfolio(request):
    return render(request, 'lostfound/portfolio.html', {'active_page': 'portfolio'})


def contacts(request):
    return render(request, 'lostfound/contacts.html', {'active_page': 'contacts'})


def about(request):
    return render(request, 'lostfound/about.html', {'active_page': 'about'})


def items(request):
    return render(request, 'lostfound/items.html', {'active_page': 'items'})


def _is_google_social_app_enabled():
    return SocialApp.objects.filter(provider='google', sites=settings.SITE_ID).exists()


@ensure_csrf_cookie
def login_view(request):
    if request.user.is_authenticated:
        return _redirect_by_role(request.user)

    form = LoginForm(request.POST or None)
    signup_form = SignUpForm()
    if request.method == 'POST' and form.is_valid():
        username_or_email = form.cleaned_data['username_or_email']
        password = form.cleaned_data['password']
        remember_me = form.cleaned_data['remember_me']

        user = None
        if User.objects.filter(email__iexact=username_or_email).exists():
            email_user = User.objects.filter(email__iexact=username_or_email).first()
            user = authenticate(request, username=email_user.username, password=password)
        if user is None:
            user = authenticate(request, username=username_or_email, password=password)

        if user is not None:
            login(request, user)
            request.session.set_expiry(1209600 if remember_me else 0)
            messages.success(request, f'Welcome back, {user.first_name or user.username}! You have been logged in successfully.')
            return _redirect_by_role(user)

        messages.error(request, 'Invalid credentials. Please try again.')

    # Filter out logout-success message so it doesn't show on the login form
    storage = get_messages(request)
    kept = []
    for msg in storage:
        # skip the explicit logout message
        if str(msg).strip() == 'You have been logged out safely.':
            continue
        kept.append((msg.level, str(msg), getattr(msg, 'extra_tags', '')))
    # re-add kept messages
    for level, text, extra in kept:
        messages.add_message(request, level, text, extra_tags=extra)

    return render(request, 'lostfound/auth.html', {
        'form': form,
        'signup_form': signup_form,
        'active_page': 'auth',
        'google_enabled': _is_google_social_app_enabled(),
    })


@ensure_csrf_cookie
def signup_view(request):
    if request.user.is_authenticated:
        return _redirect_by_role(request.user)

    form = SignUpForm(request.POST or None)
    login_form = LoginForm()
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        messages.success(request, 'Your account has been created successfully.')
        return redirect('user_dashboard')

    return render(request, 'lostfound/auth.html', {
        'form': login_form,
        'signup_form': form,
        'active_page': 'auth',
        'google_enabled': _is_google_social_app_enabled(),
    })


@login_required(login_url='/auth/')
def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out safely.')
    return redirect('landing')


@login_required(login_url='/auth/')
def user_dashboard(request):
    if request.user.is_superuser:
        return redirect('admin_dashboard')
    if request.user.is_staff:
        return redirect('staff_dashboard')

    recent_lost = LostItem.objects.filter(reported_by=request.user)[:5]
    recent_found = FoundItem.objects.filter(reported_by=request.user)[:5]
    pending_claims = Claim.objects.filter(requester=request.user, status__in=['pending', 'under_review']).count()

    context = {
        'active_page': 'dashboard',
        'total_lost': LostItem.objects.filter(reported_by=request.user).count(),
        'total_found': FoundItem.objects.filter(reported_by=request.user).count(),
        'recovered': Claim.objects.filter(requester=request.user, status='approved').count(),
        'pending_claims': pending_claims,
        'recent_lost': recent_lost,
        'recent_found': recent_found,
    }
    context.update(_dashboard_context(request, 'dashboard'))
    return render(request, 'lostfound/user_dashboard.html', context)


@login_required(login_url='/auth/')
def report_lost_page(request):
    if request.user.is_superuser or request.user.is_staff:
        return redirect('staff_dashboard')

    form = LostItemForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        lost_item = form.save(commit=False)
        lost_item.reported_by = request.user
        lost_item.save()
        _notify_other_users(
            request.user,
            'New lost item reported',
            f'A new lost item "{lost_item.name}" was reported in your area.',
            reverse('item_detail', args=['lost', lost_item.id]),
        )
        messages.success(request, 'Lost item has been reported successfully.')
        return redirect('my_reports')

    context = {'form': form}
    context.update(_dashboard_context(request, 'report_lost'))
    return render(request, 'lostfound/report_lost.html', context)


@login_required(login_url='/auth/')
def report_found_page(request):
    if request.user.is_superuser or request.user.is_staff:
        return redirect('staff_dashboard')

    form = FoundItemForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        found_item = form.save(commit=False)
        found_item.reported_by = request.user
        found_item.save()
        _match_found_with_lost(found_item)
        _notify_other_users(
            request.user,
            'New found item reported',
            f'A new found item "{found_item.name}" was posted in your area.',
            reverse('item_detail', args=['found', found_item.id]),
        )
        messages.success(request, 'Found item has been reported successfully.')
        return redirect('my_reports')

    context = {'form': form}
    context.update(_dashboard_context(request, 'report_found'))
    return render(request, 'lostfound/report_found.html', context)


@login_required(login_url='/auth/')
def my_reports(request):
    query = request.GET.get('q', '')
    category = request.GET.get('category', '')
    lost_items = LostItem.objects.filter(reported_by=request.user, is_active=True)
    found_items = FoundItem.objects.filter(reported_by=request.user, is_active=True)

    if query:
        lost_items = lost_items.filter(Q(name__icontains=query) | Q(description__icontains=query) | Q(location__icontains=query))
        found_items = found_items.filter(Q(name__icontains=query) | Q(description__icontains=query) | Q(location__icontains=query))

    if category:
        lost_items = lost_items.filter(category=category)
        found_items = found_items.filter(category=category)

    lost_paginator = Paginator(lost_items, 6)
    found_paginator = Paginator(found_items, 6)
    lost_page = request.GET.get('lost_page')
    found_page = request.GET.get('found_page')

    context = {
        'lost_items': lost_paginator.get_page(lost_page),
        'found_items': found_paginator.get_page(found_page),
        'query': query,
        'category': category,
    }
    context.update(_dashboard_context(request, 'my_reports'))
    return render(request, 'lostfound/my_reports.html', context)


@login_required(login_url='/auth/')
def lost_items(request):
    query = request.GET.get('q', '')
    category = request.GET.get('category', '')
    _expire_claimed_items()
    items = LostItem.objects.filter(is_active=True)

    if query:
        items = items.filter(Q(name__icontains=query) | Q(description__icontains=query) | Q(location__icontains=query))
    if category:
        items = items.filter(category=category)

    paginator = Paginator(items, 10)
    page = request.GET.get('page')

    context = {
        'items': paginator.get_page(page),
        'query': query,
        'category': category,
    }
    context.update(_dashboard_context(request, 'lost_items'))
    return render(request, 'lostfound/lost_items.html', context)


@login_required(login_url='/auth/')
def found_items(request):
    query = request.GET.get('q', '')
    category = request.GET.get('category', '')
    _expire_claimed_items()
    items = FoundItem.objects.filter(is_active=True)

    if query:
        items = items.filter(Q(name__icontains=query) | Q(description__icontains=query) | Q(location__icontains=query))
    if category:
        items = items.filter(category=category)

    paginator = Paginator(items, 10)
    page = request.GET.get('page')

    context = {
        'items': paginator.get_page(page),
        'query': query,
        'category': category,
    }
    context.update(_dashboard_context(request, 'found_items'))
    return render(request, 'lostfound/found_items.html', context)


def _claim_filter(item_type, item):
    if item_type == 'found':
        return {'found_item': item}
    if item_type == 'lost':
        return {'lost_item': item}
    raise Http404('Invalid item type.')


@login_required(login_url='/auth/')
def item_detail(request, item_type, item_id):
    if item_type == 'found':
        item = get_object_or_404(FoundItem, pk=item_id)
    elif item_type == 'lost':
        item = get_object_or_404(LostItem, pk=item_id)
    else:
        raise Http404('Invalid item type.')

    if not item.is_active:
        raise Http404('Item not available.')

    # Lost and found items cannot be claimed by the user who posted them
    can_claim = item.reported_by != request.user
    existing_claim = Claim.objects.filter(requester=request.user, status__in=['pending', 'under_review', 'approved'], **_claim_filter(item_type, item)).first()
    context = {
        'item': item,
        'item_type': item_type,
        'can_claim': can_claim,
        'existing_claim': existing_claim,
        'claim_url': reverse('claim_item', args=[item_id]),
    }
    context.update(_dashboard_context(request, item_type == 'found' and 'found_items' or 'lost_items'))
    return render(request, 'lostfound/item_detail.html', context)


@login_required(login_url='/auth/')
def claim_item(request, item_id):
    # try found item first, then lost item
    item = None
    item_type = None
    try:
        item = FoundItem.objects.get(pk=item_id)
        item_type = 'found'
    except FoundItem.DoesNotExist:
        try:
            item = LostItem.objects.get(pk=item_id)
            item_type = 'lost'
        except LostItem.DoesNotExist:
            raise Http404('Item not found')

    if not item.is_active:
        messages.error(request, 'This item is no longer available.')
        return redirect('found_items' if item_type == 'found' else 'lost_items')

    # Lost and found items cannot be claimed by the user who posted them
    if item_type == 'lost' and item.reported_by == request.user:
        messages.error(request, 'You cannot claim your own lost item.')
        return redirect('item_detail', item_type=item_type, item_id=item.id)
    elif item_type == 'found' and item.reported_by == request.user:
        messages.error(request, 'You cannot claim your own found item.')
        return redirect('item_detail', item_type=item_type, item_id=item.id)

    existing_claim = Claim.objects.filter(
        requester=request.user,
        found_item=(item if item_type=='found' else None),
        lost_item=(item if item_type=='lost' else None),
        status__in=['pending', 'under_review', 'approved']
    ).first()
    if existing_claim:
        messages.info(request, 'You already have an active claim for this item.')
        return redirect('claim_status')

    if request.method == 'POST':
        form = ClaimItemForm(request.POST, request.FILES)
        if form.is_valid():
            claim = form.save(commit=False)
            claim.requester = request.user
            if item_type == 'found':
                claim.found_item = item
            else:
                claim.lost_item = item
            claim.save()

            # notify owner (unless owner is claimant)
            if item.reported_by and item.reported_by != request.user:
                _send_notification(
                    item.reported_by,
                    'New claim received',
                    f'{request.user.username} submitted a claim for "{item.name}".',
                    reverse('item_detail', args=[item_type, item.id])
                )
            _notify_staff(
                'Claim request pending',
                f'A new claim request for "{item.name}" is awaiting review.',
                reverse('staff_claims')
            )

            messages.success(request, 'Claim request sent successfully.')
            return redirect('claim_status')
    else:
        form = ClaimItemForm()

    context = {'form': form, 'item': item, 'item_type': item_type}
    context.update(_dashboard_context(request, 'claim_status'))
    return render(request, 'lostfound/claim_item.html', context)


@login_required(login_url='/auth/')
def request_claim(request, item_type, item_id):
    if item_type == 'found':
        item = get_object_or_404(FoundItem, pk=item_id)
    elif item_type == 'lost':
        item = get_object_or_404(LostItem, pk=item_id)
    else:
        raise Http404('Invalid item type.')

    if not item.is_active:
        messages.error(request, 'This item is no longer available.')
        return redirect('found_items' if item_type == 'found' else 'lost_items')

    # Lost Items: only reporter can claim | Found Items: anyone can claim (except reporter)
    if item_type == 'lost':
        if item.reported_by is None or item.reported_by != request.user:
            messages.warning(request, 'Only the person who reported this lost item can claim it.')
            return redirect('item_detail', item_type=item_type, item_id=item_id)
    elif item_type == 'found' and item.reported_by == request.user:
        messages.warning(request, 'You cannot claim an item you reported yourself.')
        return redirect('item_detail', item_type=item_type, item_id=item_id)

    existing_claim = Claim.objects.filter(
        requester=request.user,
        status__in=['pending', 'under_review', 'approved'],
        **_claim_filter(item_type, item)
    ).first()
    if existing_claim:
        messages.info(request, 'You already have an active claim for this item.')
        return redirect('claim_status')

    form = ClaimRequestForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        claim = form.save(commit=False)
        claim.requester = request.user
        if item_type == 'found':
            claim.found_item = item
        else:
            claim.lost_item = item
        claim.save()

        _send_notification(
            request.user,
            'Claim submitted',
            f'Your claim request for "{item.name}" has been sent.',
            reverse('claim_status'),
        )

        if item.reported_by and item.reported_by != request.user:
            _send_notification(
                item.reported_by,
                'New claim received',
                f'Someone has requested a claim for your {item_type} item "{item.name}".',
                reverse('item_detail', args=[item_type, item_id]),
            )

        _notify_staff(
            'Claim request pending',
            f'A new claim request for "{item.name}" is awaiting review.',
            reverse('staff_claims'),
        )

        messages.success(request, 'Claim request sent. You will receive updates soon.')
        return redirect('claim_status')

    context = {'form': form, 'item': item}
    context.update(_dashboard_context(request, 'claim_status'))
    return render(request, 'lostfound/claim_request.html', context)


@login_required(login_url='/auth/')
def claim_status_page(request):
    claims = Claim.objects.filter(requester=request.user)
    context = {'claims': claims}
    context.update(_dashboard_context(request, 'claim_status'))
    return render(request, 'lostfound/claim_status.html', context)


@login_required(login_url='/auth/')
def claim_status_poll(request):
    claims = Claim.objects.filter(requester=request.user)
    claim_list = []
    for claim in claims:
        item = claim.associated_item
        claim_list.append({
            'id': claim.id,
            'item_name': item.name if item else 'Unknown item',
            'item_type': claim.item_type,
            'status': claim.status,
            'requested_at': claim.requested_at.strftime('%Y-%m-%dT%H:%M:%S'),
            'updated_at': claim.updated_at.strftime('%Y-%m-%dT%H:%M:%S'),
        })
    return JsonResponse({'claims': claim_list})


@login_required(login_url='/auth/')
def notifications_page(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    context = {'notifications': notifications}
    context.update(_dashboard_context(request, 'notifications'))
    return render(request, 'lostfound/notifications.html', context)


@login_required(login_url='/auth/')
def open_notification(request, notification_id):
    notification = get_object_or_404(Notification, pk=notification_id, user=request.user)
    if not notification.is_read:
        notification.is_read = True
        notification.save(update_fields=['is_read'])
    if notification.link:
        return redirect(notification.link)
    return redirect('notifications')


@login_required(login_url='/auth/')
def mark_notification_read(request, notification_id):
    notification = get_object_or_404(Notification, pk=notification_id, user=request.user)
    notification.is_read = True
    notification.save(update_fields=['is_read'])
    return redirect('notifications')


@login_required(login_url='/auth/')
def recent_notifications(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')[:6]
    items = []
    for note in notifications:
        items.append({
            'id': note.id,
            'title': note.title,
            'message': note.message,
            'link': note.link,
            'is_read': note.is_read,
            'created_at': note.created_at.strftime('%b %d, %Y %H:%M'),
        })
    return JsonResponse({'notifications': items})


@login_required(login_url='/auth/')
def mark_all_notifications_read(request):
    Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    return redirect('notifications')


@login_required(login_url='/auth/')
def unread_notifications_count(request):
    count = Notification.objects.filter(user=request.user, is_read=False).count()
    return JsonResponse({'unread_count': count})


@login_required(login_url='/auth/')
def profile_page(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    initial = {
        'first_name': request.user.first_name,
        'last_name': request.user.last_name,
        'email': request.user.email,
        'phone': profile.phone,
        'preferred_theme': profile.preferred_theme,
    }
    form = UserProfileForm(request.POST or None, request.FILES or None, instance=profile, initial=initial)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Profile saved successfully.')
        return redirect('profile')

    context = {'form': form}
    context.update(_dashboard_context(request, 'profile'))
    return render(request, 'lostfound/profile.html', context)


@login_required(login_url='/auth/')
def settings_page(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    form = SettingsForm(request.POST or None, instance=profile)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Settings updated successfully.')
        return redirect('settings')

    context = {'form': form}
    context.update(_dashboard_context(request, 'settings'))
    return render(request, 'lostfound/settings.html', context)


@login_required(login_url='/auth/')
def help_center(request):
    context = _dashboard_context(request, 'help_center')
    return render(request, 'lostfound/help_center.html', context)


@login_required(login_url='/auth/')
def staff_dashboard(request):
    if not (request.user.is_staff or request.user.is_superuser):
        return redirect('user_dashboard')

    total_lost = LostItem.objects.count()
    total_found = FoundItem.objects.count()
    total_users = User.objects.filter(is_superuser=False).count()
    total_staff = User.objects.filter(is_staff=True, is_superuser=False).count()
    total_claims = Claim.objects.count()
    pending_claims = Claim.objects.filter(status__in=['pending', 'under_review']).count()
    approved_claims = Claim.objects.filter(status='approved').count()
    rejected_claims = Claim.objects.filter(status='rejected').count()
    recent_claims = Claim.objects.select_related('requester', 'found_item', 'lost_item').order_by('-requested_at')[:6]
    recent_lost = LostItem.objects.order_by('-reported_at')[:5]
    recent_found = FoundItem.objects.order_by('-reported_at')[:5]

    context = {
        'active_page': 'staff_dashboard',
        'total_lost': total_lost,
        'total_found': total_found,
        'total_users': total_users,
        'total_staff': total_staff,
        'total_claims': total_claims,
        'pending_claims': pending_claims,
        'approved_claims': approved_claims,
        'rejected_claims': rejected_claims,
        'recent_claims': recent_claims,
        'recent_lost': recent_lost,
        'recent_found': recent_found,
    }
    context.update(_dashboard_context(request, 'staff_dashboard'))
    return render(request, 'lostfound/staff_dashboard.html', context)


@login_required(login_url='/auth/')
def staff_claims(request):
    if not (request.user.is_staff or request.user.is_superuser):
        return redirect('user_dashboard')

    claims = Claim.objects.select_related('requester', 'found_item', 'lost_item').all()
    context = {
        'claims': claims,
    }
    context.update(_dashboard_context(request, 'staff_claims'))
    return render(request, 'lostfound/staff_claims.html', context)


@login_required(login_url='/auth/')
def staff_update_claim(request, claim_id):
    if not (request.user.is_staff or request.user.is_superuser):
        return redirect('user_dashboard')

    claim = get_object_or_404(Claim, pk=claim_id)
    form = ClaimStatusUpdateForm(request.POST or None, instance=claim)
    if request.method == 'POST' and form.is_valid():
        previous_status = claim.status
        claim = form.save(commit=False)
        claim.reviewed_by = request.user
        claim.save()

        item = claim.associated_item
        if item:
            if previous_status != 'approved' and claim.status == 'approved':
                item.mark_as_approved()
            elif claim.status == 'returned':
                item.is_active = False
                item.save()
            elif previous_status == 'approved' and claim.status != 'approved':
                item.is_claimed = False
                item.approved_at = None
                item.is_active = True
                item.save()

        ActivityLog.objects.create(
            staff=request.user,
            action=f'Claim {claim.id} status updated',
            target_claim=claim,
            notes=f'Status changed from {previous_status} to {claim.status}',
        )
        _send_notification(
            claim.requester,
            'Claim status updated',
            f'Your claim for "{claim.associated_item.name if claim.associated_item else "item"}" is now {claim.get_status_display()}.',
            reverse('claim_status'),
        )
        messages.success(request, 'Claim status has been updated.')
        return redirect('staff_claims')

    context = {'claim': claim, 'form': form}
    context.update(_dashboard_context(request, 'staff_claims'))
    return render(request, 'lostfound/staff_update_claim.html', context)


@login_required(login_url='/auth/')
def admin_dashboard(request):
    if not request.user.is_superuser:
        return redirect('user_dashboard')

    total_lost = LostItem.objects.count()
    total_found = FoundItem.objects.count()
    total_users = User.objects.count()
    total_staff = User.objects.filter(is_staff=True).count()
    total_claims = Claim.objects.count()
    pending_reviews = Claim.objects.filter(status__in=['pending', 'under_review']).count()
    total_notifications = Notification.objects.count()
    recent_activity = ActivityLog.objects.select_related('staff', 'target_claim').all()[:10]
    recent_lost = LostItem.objects.order_by('-reported_at')[:5]
    recent_found = FoundItem.objects.order_by('-reported_at')[:5]

    context = {
        'active_page': 'admin_dashboard',
        'total_lost': total_lost,
        'total_found': total_found,
        'total_users': total_users,
        'total_staff': total_staff,
        'total_claims': total_claims,
        'pending_reviews': pending_reviews,
        'total_notifications': total_notifications,
        'recent_activity': recent_activity,
        'recent_lost': recent_lost,
        'recent_found': recent_found,
    }
    context.update(_dashboard_context(request, 'admin_dashboard'))
    return render(request, 'lostfound/admin_dashboard.html', context)

