from django.urls import path
from . import views

urlpatterns = [
    # HOME & STATIC
    path('', views.landing, name='landing'),
    path('developer/', views.developer, name='developer'),
    path('portfolio/', views.portfolio, name='portfolio'),
    path('contacts/', views.contacts, name='contacts'),
    path('about/', views.about, name='about'),
    path('items/', views.items, name='items'),

    # AUTH
    path('auth/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),

    # USER DASHBOARD
    path('dashboard/user/', views.user_dashboard, name='user_dashboard'),
    path('dashboard/user/report-lost/', views.report_lost_page, name='report_lost_page'),
    path('dashboard/user/report-found/', views.report_found_page, name='report_found_page'),
    path('dashboard/user/reports/', views.my_reports, name='my_reports'),
    path('dashboard/user/claims/', views.claim_status_page, name='claim_status'),
    path('dashboard/user/notifications/', views.notifications_page, name='notifications'),
    path('dashboard/user/profile/', views.profile_page, name='profile'),
    path('dashboard/user/settings/', views.settings_page, name='settings'),
    path('dashboard/user/help/', views.help_center, name='help_center'),

    # STAFF / ADMIN
    path('dashboard/staff/', views.staff_dashboard, name='staff_dashboard'),
    path('dashboard/staff/claims/', views.staff_claims, name='staff_claims'),
    path('dashboard/staff/claims/<int:claim_id>/update/', views.staff_update_claim, name='staff_update_claim'),
    path('dashboard/admin/', views.admin_dashboard, name='admin_dashboard'),

    # ITEM MANAGEMENT
    path('items/lost/', views.lost_items, name='lost_items'),
    path('items/found/', views.found_items, name='found_items'),
    path('items/<str:item_type>/<int:item_id>/', views.item_detail, name='item_detail'),
    path('items/<str:item_type>/<int:item_id>/claim/', views.request_claim, name='request_claim'),
    path('claim/<int:item_id>/', views.claim_item, name='claim_item'),

    # NOTIFICATIONS / API
    path('notifications/open/<int:notification_id>/', views.open_notification, name='open_notification'),
    path('notifications/mark-read/<int:notification_id>/', views.mark_notification_read, name='mark_notification_read'),
    path('notifications/mark-all-read/', views.mark_all_notifications_read, name='mark_all_notifications_read'),
    path('api/claims/status/', views.claim_status_poll, name='claim_status_poll'),
    path('api/notifications/unread-count/', views.unread_notifications_count, name='unread_notifications_count'),
    path('api/notifications/recent/', views.recent_notifications, name='recent_notifications'),
]
