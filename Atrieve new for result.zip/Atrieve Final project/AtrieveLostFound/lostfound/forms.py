from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UsernameField
from django.utils.translation import gettext_lazy as _

from .models import LostItem, FoundItem, Claim, UserProfile

CATEGORY_OPTIONS = [
    ('electronics', 'Electronics'),
    ('accessories', 'Accessories'),
    ('documents', 'Documents'),
    ('fashion', 'Fashion'),
    ('travel', 'Travel'),
    ('others', 'Others'),
]

CLAIM_STATUS_CHOICES = [
    ('pending', 'Pending'),
    ('under_review', 'Under Review'),
    ('approved', 'Approved'),
    ('rejected', 'Rejected'),
    ('returned', 'Item Returned'),
]


class LoginForm(forms.Form):
    username_or_email = forms.CharField(
        label=_('Username or Email'),
        max_length=150,
        widget=forms.TextInput(attrs={
            'placeholder': 'Username or Email',
            'autocomplete': 'username'
        })
    )
    password = forms.CharField(
        label=_('Password'),
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Password',
            'autocomplete': 'current-password'
        })
    )
    remember_me = forms.BooleanField(
        label=_('Remember me'),
        required=False,
        initial=False,
    )


class SignUpForm(forms.ModelForm):
    password1 = forms.CharField(
        label=_('Password'),
        strip=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password', 'placeholder': 'Create a password'}),
    )
    password2 = forms.CharField(
        label=_('Confirm Password'),
        strip=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password', 'placeholder': 'Confirm your password'}),
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name')
        field_classes = {'username': UsernameField}
        widgets = {
            'username': forms.TextInput(attrs={'placeholder': 'Username', 'autocomplete': 'username'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Email address', 'autocomplete': 'email'}),
            'first_name': forms.TextInput(attrs={'placeholder': 'First name', 'autocomplete': 'given-name'}),
            'last_name': forms.TextInput(attrs={'placeholder': 'Last name', 'autocomplete': 'family-name'}),
        }

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError(_('An account with this email already exists.'))
        return email

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')
        if password1 and password2 and password1 != password2:
            self.add_error('password2', _('Passwords must match.'))
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        user.email = self.cleaned_data['email'].lower()
        if commit:
            user.save()
        return user


class LostItemForm(forms.ModelForm):
    class Meta:
        model = LostItem
        fields = [
            'name', 'category', 'description', 'location', 'date_lost',
            'contact_email', 'contact_phone', 'image',
        ]
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Item name'}),
            'category': forms.Select(choices=CATEGORY_OPTIONS),
            'description': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Describe what was lost'}),
            'location': forms.TextInput(attrs={'placeholder': 'Where was it lost?'}),
            'date_lost': forms.DateInput(attrs={'type': 'date'}),
            'contact_email': forms.EmailInput(attrs={'placeholder': 'Your email address'}),
            'contact_phone': forms.TextInput(attrs={'placeholder': 'Your phone or WhatsApp number'}),
        }


class FoundItemForm(forms.ModelForm):
    class Meta:
        model = FoundItem
        fields = [
            'name', 'category', 'description', 'location', 'date_found', 'image',
        ]
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Item name'}),
            'category': forms.Select(choices=CATEGORY_OPTIONS),
            'description': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Describe where it was found'}),
            'location': forms.TextInput(attrs={'placeholder': 'Found location'}),
            'date_found': forms.DateInput(attrs={'type': 'date'}),
        }


class ClaimRequestForm(forms.ModelForm):
    full_name = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Your full name'}),
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'placeholder': 'Your email address'}),
    )
    phone_number = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Your phone number'}),
    )
    proof_of_ownership = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'rows': 4,
            'placeholder': 'Describe your proof of ownership',
        }),
    )
    note = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'rows': 4,
            'placeholder': 'Additional details for the staff',
        }),
    )
    proof_image = forms.FileField(
        required=False,
        widget=forms.ClearableFileInput(attrs={'accept': 'image/*'}),
    )

    class Meta:
        model = Claim
        fields = [
            'full_name', 'email', 'phone_number',
            'proof_of_ownership', 'note', 'proof_image',
        ]


class ClaimItemForm(forms.ModelForm):
    note = forms.CharField(
        required=True,
        widget=forms.Textarea(attrs={'rows': 4, 'placeholder': 'Describe your claim'}),
        label='Message'
    )

    class Meta:
        model = Claim
        fields = ['note', 'proof_image']

class UserProfileForm(forms.ModelForm):
    first_name = forms.CharField(required=False, widget=forms.TextInput(attrs={'placeholder': 'First name'}))
    last_name = forms.CharField(required=False, widget=forms.TextInput(attrs={'placeholder': 'Last name'}))
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'placeholder': 'Email address'}))

    class Meta:
        model = UserProfile
        fields = ['phone', 'preferred_theme', 'profile_image']
        widgets = {
            'phone': forms.TextInput(attrs={'placeholder': 'Contact phone'}),
            'preferred_theme': forms.Select(attrs={'class': 'input-select'}),
            'profile_image': forms.ClearableFileInput(attrs={'accept': 'image/*'}),
        }

    def save(self, commit=True):
        profile = super().save(commit=False)
        user = profile.user
        user.email = self.cleaned_data['email'].lower()
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
            profile.save()
        return profile


class SettingsForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['preferred_theme']
        widgets = {
            'preferred_theme': forms.Select(attrs={'class': 'input-select'}),
        }


class ClaimStatusUpdateForm(forms.ModelForm):
    class Meta:
        model = Claim
        fields = ['status']
        widgets = {
            'status': forms.Select(choices=CLAIM_STATUS_CHOICES, attrs={'class': 'input-select'}),
        }
