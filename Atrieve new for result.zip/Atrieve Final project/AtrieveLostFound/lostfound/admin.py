from django.contrib import admin
from .models import ActivityLog, LostItem, FoundItem, Claim, Notification, UserProfile


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone', 'preferred_theme', 'updated_at')
    search_fields = ('user__username', 'phone')
    raw_id_fields = ('user',)


@admin.register(LostItem)
class LostItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'location', 'date_lost', 'reported_by', 'matched_found_item')
    search_fields = ('name', 'description', 'location', 'contact_email', 'contact_phone')
    list_filter = ('category', 'date_lost',)
    raw_id_fields = ('reported_by', 'matched_found_item')


@admin.register(FoundItem)
class FoundItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'location', 'date_found', 'reported_by', 'matched_lost_item')
    search_fields = ('name', 'description', 'location')
    list_filter = ('category', 'date_found',)
    raw_id_fields = ('reported_by', 'matched_lost_item')


@admin.register(Claim)
class ClaimAdmin(admin.ModelAdmin):
    list_display = ('id', 'requester', 'found_item', 'status', 'reviewed_by', 'requested_at', 'updated_at', 'has_proof_image')
    search_fields = ('requester__username', 'found_item__name', 'lost_item__name', 'note', 'email', 'phone_number')
    list_filter = ('status', 'requested_at')
    raw_id_fields = ('requester', 'found_item', 'reviewed_by')
    readonly_fields = ('requested_at', 'updated_at', 'proof_image_preview')
    fieldsets = (
        ('Claim Details', {
            'fields': ('requester', 'found_item', 'lost_item', 'status', 'reviewed_by')
        }),
        ('Claimant Information', {
            'fields': ('full_name', 'email', 'phone_number')
        }),
        ('Proof & Description', {
            'fields': ('proof_of_ownership', 'proof_image', 'proof_image_preview', 'note')
        }),
        ('Timestamps', {
            'fields': ('requested_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def has_proof_image(self, obj):
        return bool(obj.proof_image)
    has_proof_image.short_description = 'Has Proof Image'
    has_proof_image.boolean = True
    
    def proof_image_preview(self, obj):
        if obj.proof_image:
            return f'<img src="{obj.proof_image.url}" style="max-width: 300px; max-height: 300px;" />'
        return 'No image provided'
    proof_image_preview.allow_tags = True
    proof_image_preview.short_description = 'Proof Image Preview'


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ('staff', 'action', 'target_claim', 'timestamp')
    search_fields = ('staff__username', 'action', 'notes')
    list_filter = ('timestamp',)
    raw_id_fields = ('staff', 'target_claim')


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'title', 'is_read', 'created_at')
    search_fields = ('user__username', 'title', 'message')
    list_filter = ('is_read', 'created_at')
    raw_id_fields = ('user',)
